 <?php
/////////////////////////////// SIGNUP CODE 
require 'library.php';
include 'database.php';
$app = new DemoLib();

// <!-- ---------- Posting data --------------- -->
     
        $influname =  isset($_POST['fname']) ? $_POST['fname'] : ''; 
       // $infldate =  isset($_POST['date']) ? $_POST['date'] : ''; 
        $infldate = date("Y-m-d H:i:s"); 
        $inflmessage =  isset($_POST['imessage']) ? $_POST['imessage'] : '';
        $rating = 		isset($_POST['rating']) ? $_POST['rating'] : '';

   $rows = $app->getdata();

  if(isset($_POST['influencer-submit'])){
    
  try{
            // Check if username is already existing
           $user_id_isthere = $app->chkDetails($influname); 
           if ($_POST['fname'] == "") {
                $register_error_message = ' Full name is required!';
            } else if  (!$user_id_isthere) {

                  $user_id = $app->Registerinflu($_POST['fname'],$_POST['imessage'],$_POST['rating']);
                  $mssgvalues = $app->getdata();
                  echo '<script language="javascript">';
				echo 'alert("Thanks for your Review")';
				echo '</script>';
              header("Location: http://dreamlandfarms.in");

            }else{

            	echo '<script language="javascript">';
				echo 'alert("User already exits")';
				echo '</script>';
            }
          
             
    } // try ends
  catch(PDOException $error){
        echo 'ERROR: ' . $error->getMessage();
  }$conn = null;

}



?> 

<!doctype html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<title>Our Services | Dreamlandfarms </title>
	
	<meta name="description" content="Dreamlandfarms farmhouse is the ideal getaway for anyone who loves the sea. 
	Away from hues and cries of this world, this farmhouse farmhouse serves as a great weekend gateway for farmhouse lovers.">
	
	<meta name="keywords" content="Dreamlandfarms farmhouse arnala, best farmhouse in arnala, farmhouse in arnala, farmhouse in virar, waterpark in arnala farmhouse,
	farmhouse in arnala farmhouse, arnala farmhouse farmhouse, Dreamlandfarms farm arnala, sea facing farmhouse, family farmhouse, amazing slides, jungle theme, waterfall in arnala,
	vasai virar farmhouse, biggest farmhouse in vasai virar,holiday place, weekend fun, luxury farmhouse in mumbai, virar west">
	
	<meta name="author" content="Dreamlandfarms farmhouse karjat">
	<meta name="viewport"
		  content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,700,400italic,700italic%7cPlayfair+Display:400,700%7cGreat+Vibes'
		  rel='stylesheet' type='text/css'><!-- Attach Google fonts -->
	<link rel="stylesheet" type="text/css" href="../assets/css/styles.css"><!-- Attach the main stylesheet file -->
	<link rel="stylesheet" type="text/css" href="starability-minified/starability-all.min.css"/> <!-- CSS of stars -->

	
	<link rel="apple-touch-icon" sizes="57x57" href="../assets/img/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="../assets/img/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="../assets/img/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="../assets/img/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="../assets/img/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="../assets/img/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="../assets/img/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="../assets/img/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="../assets/img/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="../assets/img/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="../assets/img/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="../assets/img/favicon-16x16.png">
<link rel="manifest" href="../assets/img/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="../assets/img/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">

</head>
<body>
	<div class="main-wrapper">
		<!-- Header Section -->
		<header id="main-header">
			<div class="inner-container container">
				<div class="l-sec col-xs-8 col-sm-6 col-md-3">
					<a href="#" id="t-logo">
						<br>
						
						<img href="../index.html" src="../assets/img/" alt="dreamlandfarms">
					</a>
				</div>
				
				
				
				<div class="r-sec col-xs-4 col-sm-6 col-md-9">
					<nav id="main-menu">
						<ul class="list-inline">
							<li><a href="../index.html">Home</a> </li>
							<li><a href="about.html">About</a> </li>
							<li class="active"><a href="services.html">Services</a></li> 
							<li><a href="packages.html">Packages</a></li> 
							<li><a href="gallery-grid.html">Gallery</a> </li>
							<li><a href="contact.html">Contact</a></li>
							<li><a href="review.php">Review</a></li>
							<a href="book.html" id="header-book-bow" class="ravis-btn btn-type-2"><span>Book Now</span> <i class="fa fa-calendar"></i></a>
						</ul>
					</nav>
					<div id="main-menu-handle" class="ravis-btn btn-type-2"><i class="fa fa-bars"></i><i class="fa fa-close"></i></div><!-- Mobile Menu handle -->
					
				</div>
			</div>
			<div id="mobile-menu-container"></div>
		</header>
		<!-- End of Header Section -->

		<!--Breadcrumb Section-->
		<section id="breadcrumb-section" data-bg-img="../assets/img/slider/mainbg.jpg">
			<div class="inner-container container">
				<div class="ravis-title">
					<div class="inner-box">
						<div class="title">Reviews</div>
						<div class="sub-title">Share your experience with Us</div>
					</div>
				</div>

				<div class="breadcrumb">
					<ul class="list-inline">
						<li><a href="../index.html">Home</a></li>
						<li class="current"><a href="#">Our Services</a></li>
					</ul>
				</div>
			</div>
		</section>
		<!--End of Breadcrumb Section-->

		<!--Welcome Section-->
		<section id="welcome-section" class="simple">
			<div class="inner-container container">
				<div class="ravis-title-t-2">
					<div class="title"><span>Testimonials </span></div>
					<div class="sub-title">We provide the most luxurious services</div>
				</div>
				
			</div>
		</section>
		<!--End of Welcome Section-->

	



		<section id="history-section">
			<div class="inner-container container">
			
				<div class="history-timeline clearfix">
					<div class="history-boxes col-md-12 col-xs-10 animated-box" data-animation="fadeInLeft">
						
						
						<div class="history-boxes-inner">
					
							  <form id="register-form" action="review.php" method="post" role="form" name= "influformdata" value ="influ"  enctype="multipart/form-data" >
                    
				                  <div class="form-group">
				                    <input type="text" name="fname" id="fname" tabindex="1" class="form-control" placeholder="Your Name" value="">
				                  </div>
    
				                  <div class="form-group">
				                    <textarea rows="4" cols="50" name="imessage" id="ipmessage" class="form-control"  placeholder="Something you want to tell us"></textarea>
				                  </div>

				                  <!-- STARS  -->

				                   
									    <!-- Change starability-basic to different class to see animations. -->
									    <fieldset class="starability-basic">
									      
										      <input type="radio" id="no-rate" class="input-no-rate" name="rating" value="0" checked aria-label="No rating." />

										      <input type="radio" id="rate1" name="rating" value="1" OnClick="getstar1()"/>
										      <label for="rate1">1 star.</label>

										      <input type="radio" id="rate2" name="rating" value="2" OnClick="getstar2()"/>
										      <label for="rate2">2 stars.</label>

										      <input type="radio" id="rate3" name="rating" value="3" OnClick="getstar3()"/>
										      <label for="rate3">3 stars.</label>

										      <input type="radio" id="rate4" name="rating" value="4" OnClick="getstar4()"/>
										      <label for="rate4">4 stars.</label>

										      <input type="radio" id="rate5" name="rating" value="5" OnClick="getstar5()"/>
										      <label for="rate5">5 stars.</label>

										      <span class="starability-focus-ring"></span>

									      
									    </fieldset>
									

				                  <!-- STARS END -->

				                    
				                   <div>
				                      <div class="ravis-btn btn-type-2">
				                        <input type="submit" name="influencer-submit" id="register-submit" tabindex="4" class="ravis-btn btn-type-2"  value="Enter" >
				                      </div>
				                  </div>

				                </form>
						</div>
					</div>
				</div>
			</div>
		</section>


			<section  id="history-section">
			<div class="inner-container container">
				<div class="history-timeline clearfix">
					<div class="history-boxes col-md-12 col-xs-10 animated-box" data-animation="fadeInLeft">
						<div class="history-boxes-inner">
							<?php
							 foreach($rows as $key => $arrRows){

							 // echo '<div><strong>Name: </strong>' .$arrRows['Name']. ', <span>' .$arrRows['thisdate'].',</span><span>'.$arrRows['rating'].'</span><br><strong>Message: </strong>' .$arrRows['message']. '</div><br />';



							 echo '<div><strong>Name: </strong>' .$arrRows['Name']. ', <span>' .$arrRows['thisdate'].',</span><span id ="addstar"></span><br><strong>Message: </strong>' .$arrRows['message']. '</div><br />';



							  $no_stars= $arrRows['rating'];
							 echo $no_stars;
							// for($i = 0; $i<$no_stars; $i++ ){

							 	echo "
							 	<script type=\"text/javascript\"> 
							 	 
							 	 var addstar = document.getElementById('addstar');

								 var myfieldset = document.querySelector('fieldset');
							 	 var norate= document.getElementById('no-rate');
							 	 
							 	 var input = document.createElement('input');
							 	 input.setAttribute('type','radio');
							 	 input.classList.add('starability-basic'); 

							 	 var norate = norate.appendChild(input);  
							 	 var myfieldset = myfieldset.appendChild(norate);

							 	 addstar.appendChild(myfieldset);
							 	 

							 	 </script>
							 	 ";

							 //}
						}
						?>
						</div>
					</div>
				</div>
			</div>
		</section>








		<!--Footer Section-->
		<footer id="main-footer">
			<div class="inner-container container">
				<div class="t-sec clearfix">
					
					
					<div class="widget-box col-sm-6 col-md-9">
						<a href="#" id="f-logo">
							<span class="title">Dreamlandfarms Karjat</span>
							
						</a>
						<div class="widget-content text-widget">
							Close to the city, home to nature's beauty. Relive your stress and tension in a day. 
							Giving us an opportunity to cater your every need. Just about 30 kms from borivali, placed arnala farmhouse,Located near the farmhouse. 
							The Dreamlandfarms farmhouse has truly locked the feel of rural village having beautiful natural canopies, serene green Banana plantations, 
							Tall swaying coconut palm trees, whistling crop fields, village style kutirs and DJ Music to enrich your souls. 
							
							<br> <br>
												
						<ul><li><i class="fa fa-check-square-o fa-2x"> &nbsp </i><a href="terms-and-condition.html">Terms & Conditions</a> </li></ul>
						</div>
					</div>
					
				
					<div class="widget-box col-sm-6 col-md-3">
						<h4 class="title">Contact Us</h4>
						<div class="widget-content contact">
							<ul class="contact-info">
								<li>
									<i class="fa fa-home"></i>
									Dreamlandfarms Farm,Arnala farmhouse,Virar (W) 
								</li>
								<li>
									<i class="fa fa-phone"></i>
									<a href="tel:9158533988 " >91585 33988</a> / <a href="tel:7888188999 " >7888188999</a> 
									/ <a href="tel:9822046999 " >9822046999</a> / <a href="tel:9226937820 " >9226937820</a> 
								</li>
								<li>
									<i class="fa fa-envelope"></i>
									<a href="mailto:Dreamlandfarmhousefarmhouse@hotmail.com">akksks@hotmail.com</a>
								</li>
							</ul>
						</div>
					</div>
				</div>
				<div class="b-sec clearfix">
					<div class="copy-right">
						Made With <i class="fa fa-heart"></i> by <a href="https://theviraladvertising.com/"
															   target="_blank">TheViralAdvertising</a>  <br>© DreamLandFarms 2019. All Rights
						Reserved.
					</div>
					<ul class="social-icons list-inline">
						<li><a href="https://www.facebook.com/Dreamlandfarmhouse-103280533099583/" target="_blank"><i class="fa fa-facebook"></i></a></li>
						<li><a href="#"><i class="fa fa-twitter"></i></a></li>
						<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
					</ul>
				</div>
			</div>
		</footer>
		<!--End of Footer Section-->

	</div>

	<!-- JS Include Section -->
	<script type="text/javascript" src="../assets/js/jquery-3.1.0.min.js"></script>
	<script type="text/javascript" src="../assets/js/helper.js"></script>
	<script type="text/javascript" src="../assets/js/owl.carousel.min.js"></script>
	<script type="text/javascript" src="../assets/js/template.js"></script>
	<script type="text/javascript" src="../assets/js/stars.js"></script>
</body>

</html>