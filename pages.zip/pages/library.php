 
 <?php
class DemoLib
{
    public function Registerinflu($pgname, $inflmessage,$rating)
    {

        $influname =  isset($_POST['fname']) ? $_POST['fname'] : ''; 
        $infldate = date("Y-m-d H:i:s"); 
        $inflmessage =  isset($_POST['imessage']) ? $_POST['imessage'] : '';
        $rating =       isset($_POST['rating']) ? $_POST['rating'] : '';

            try {
                $db = DB();
                $query = $db->prepare("INSERT INTO `cmttable`(`Name`,`thisdate`,`message`,`rating`) VALUES(:fullname,:thisdate,:inflmessage,:rating)");
    
                $query->bindValue(':fullname', $influname);
                $query->bindValue(':thisdate', $infldate);
                $query->bindValue(':inflmessage', $inflmessage);
                $query->bindValue(':rating', $rating);

                $query->execute();
                unset($_POST['fname']);
                unset($_POST['date']);
                unset($_POST['imessage']);
                unset($_POST['rating']);
    
            } catch (PDOException $e) {
                exit($e->getMessage());
            }
    }
    


    public function getdata()
    {
        
        try {
            $db = DB();
            $query = $db->prepare("SELECT Name, message, thisdate, rating FROM cmttable ");
            $query->execute();


            $rows = $query->fetchAll(PDO::FETCH_ASSOC);
            return $rows;
/*
            foreach($rows as $key => $arrRows){
               echo '<div class="ravis-btn btn-type-2"><strong>Name: </strong>' .$arrRows['Name']. '<br>Message:' .$arrRows['message']. '</div><br />';
                return  $arrRows;
             
            }
             */  
           
        }
            
         catch (PDOException $e) {
            exit($e->getMessage());
        }
    }


    public function chkDetails($influname)
    {
        try {
            $db = DB();
            $query = $db->prepare("SELECT * FROM cmttable WHERE Name=:name");
            $query->bindValue(':name', $influname);
            $query->execute();
            if ($query->rowCount() == 0) {  //User not present 
               // return $query->fetch(PDO::FETCH_OBJ);
                return false;
            }
            else{
                return true;
            }
        } catch (PDOException $e) {
            exit($e->getMessage());
        }
    }

 
}
?>

