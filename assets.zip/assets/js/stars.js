
  function getstar1(){
    var val = document.getElementById('rate1').value;
    console.log(val);

    var paragraph = document.getElementById("p");
   // paragraph.innerHTML = "Thanks for your reviews";
  }

    function getstar2(){
    var val = document.getElementById('rate2').value;
    console.log(val);
     var paragraph = document.getElementById("p");
    //paragraph.innerHTML = "Thanks for your reviews";
  }
    function getstar3(){
    var val = document.getElementById('rate3').value;
    console.log(val);
     var paragraph = document.getElementById("p");
    //paragraph.innerHTML = "Thanks for your reviews";
  }
    function getstar4(){
    var val = document.getElementById('rate4').value;
    console.log(val);
     var paragraph = document.getElementById("p");
    //paragraph.innerHTML = "Thanks for your reviews";
  }
    function getstar5(){
    var val = document.getElementById('rate5').value;
    console.log(val);
     var paragraph = document.getElementById("p");
    //paragraph.innerHTML = "Thanks for your reviews";
  }